go build -o bin/application
