# Bumpin_BackendApplication
This is a Go application to support querying a DynamoDB database.
